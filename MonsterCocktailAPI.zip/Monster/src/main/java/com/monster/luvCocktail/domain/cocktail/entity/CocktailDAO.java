package com.monster.luvCocktail.domain.cocktail.entity;

import org.springframework.jdbc.core.JdbcTemplate;

public class CocktailDAO extends JdbcTemplate {

}
