package com.monster.luvCocktail.domain.cocktail;

public class  CocktailAPI {

    public static void main(String[] args) {


    }
}
