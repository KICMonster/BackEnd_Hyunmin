package com.monster.luvCocktail.domain.cocktail.entity;

import lombok.Getter;

@Getter
public class Detail {
    private String strIngredient;
    private String strMeasure;
}
