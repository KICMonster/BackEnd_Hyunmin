-- 설문 결과 테이블 생성
# CREATE TABLE RECORD_RESULT
# (
# 	RESULT_ID   NVARCHAR(255) NOT NULL PRIMARY KEY, -- 결과 ID
# 	RESULT_TEXT TEXT          NOT NULL              -- 결과 내용
# );

-- 설문 테이블 생성
CREATE TABLE RECORD
(
	QUESTION_CD NVARCHAR(255) NOT NULL PRIMARY KEY, -- 설문 코드
	QUESTION    TEXT          NOT NULL,             -- 설문 내용
	RECORD_PD   NVARCHAR(255) NULL,                 -- 설문 기간
	RECORD_RES  NVARCHAR(255) NULL                  -- 결과 (외래 키)
# 	CONSTRAINT FK_RECORD_RES FOREIGN KEY (RECORD_RES) REFERENCES RECORD_RESULT (RESULT_ID) -- 외래 키 제약조건
);

-- 투표 테이블 생성
CREATE TABLE VOTE
(
	VOTE_ID     INT AUTO_INCREMENT PRIMARY KEY, -- 투표 ID
	TITLE       VARCHAR(255) NOT NULL,          -- 투표 제목
	DESCRIPTION TEXT         NOT NULL           -- 투표 설명
);

-- 선택 테이블 생성
CREATE TABLE CHOICE
(
	CHOICE_ID     BIGINT AUTO_INCREMENT PRIMARY KEY,                             -- 선택지 ID
	VOTE_ID       INT          NOT NULL,                                      -- 투표 ID
	CHOICE_TEXT   VARCHAR(255) NOT NULL,                                      -- 선택지 내용
	LIKE_COUNT    INT DEFAULT 0,                                              -- 좋아요 투표
	DISLIKE_COUNT INT DEFAULT 0,                                              -- 싫어요 투표
	CONSTRAINT FK_VOTE_CHOICE FOREIGN KEY (VOTE_ID) REFERENCES VOTE (VOTE_ID) -- 외래 키 제약조건
);

-- 날씨 테이블 생성
CREATE TABLE WEATHER
(
	WEATHER_ID       NVARCHAR(255) NOT NULL PRIMARY KEY, -- 날씨정보 ID
	WEATHER_CATEGORY VARCHAR(255),                       -- 날씨 카테고리
	WEATHER_STATUS   VARCHAR(10)   NOT NULL              -- 날씨정보
);

-- 칵테일 테이블 생성
CREATE TABLE COCKTAIL
(
	COCKTAIL_ID           BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,                  -- 칵테일 ID
	COCKTAIL_NAME         VARCHAR(255),                                                     -- 칵테일 이름
	COCKTAIL_CATEGORY     VARCHAR(255),                                                     -- 칵테일 카테고리
	COCKTAIL_ALCOHOLIC    VARCHAR(255),                                                     -- 칵테일 알코올 여부
	COCKTAIL_GLASS        VARCHAR(255),                                                     -- 칵테일에 사용되는 잔
	COCKTAIL_INSTRUCTIONS TEXT,                                                             -- 칵테일 제조법
	COCKTAIL_IMAGE_URL    VARCHAR(255),                                                     -- 칵테일 이미지 URL
	CCL                   VARCHAR(255),                                                     -- CCL 확인 여부
	RC_WEATHER            NVARCHAR(255),                                                    -- 날씨 ID
	COCKTAIL_INGREDIENT1  VARCHAR(255),                                                     -- 칵테일 재료 1
	COCKTAIL_INGREDIENT2  VARCHAR(255),                                                     -- 칵테일 재료 2
	COCKTAIL_INGREDIENT3  VARCHAR(255),                                                     -- 칵테일 재료 3
	COCKTAIL_INGREDIENT4  VARCHAR(255),                                                     -- 칵테일 재료 4
	COCKTAIL_INGREDIENT5  VARCHAR(255),                                                     -- 칵테일 재료 5
	COCKTAIL_INGREDIENT6  VARCHAR(255),                                                     -- 칵테일 재료 6
	COCKTAIL_INGREDIENT7  VARCHAR(255),                                                     -- 칵테일 재료 7
	COCKTAIL_INGREDIENT8  VARCHAR(255),                                                     -- 칵테일 재료 8
	COCKTAIL_INGREDIENT9  VARCHAR(255),                                                     -- 칵테일 재료 9
	COCKTAIL_INGREDIENT10 VARCHAR(255),                                                     -- 칵테일 재료 10
	COCKTAIL_INGREDIENT11 VARCHAR(255),                                                     -- 칵테일 재료 11
	COCKTAIL_INGREDIENT12 VARCHAR(255),                                                     -- 칵테일 재료 12
	COCKTAIL_INGREDIENT13 VARCHAR(255),                                                     -- 칵테일 재료 13
	COCKTAIL_INGREDIENT14 VARCHAR(255),                                                     -- 칵테일 재료 14
	COCKTAIL_INGREDIENT15 VARCHAR(255),                                                     -- 칵테일 재료 15
	COCKTAIL_MEASURE1     VARCHAR(255),                                                     -- 칵테일 재료 양 1
	COCKTAIL_MEASURE2     VARCHAR(255),                                                     -- 칵테일 재료 양 2
	COCKTAIL_MEASURE3     VARCHAR(255),                                                     -- 칵테일 재료 양 3
	COCKTAIL_MEASURE4     VARCHAR(255),                                                     -- 칵테일 재료 양 4
	COCKTAIL_MEASURE5     VARCHAR(255),                                                     -- 칵테일 재료 양 5
	COCKTAIL_MEASURE6     VARCHAR(255),                                                     -- 칵테일 재료 양 6
	COCKTAIL_MEASURE7     VARCHAR(255),                                                     -- 칵테일 재료 양 7
	COCKTAIL_MEASURE8     VARCHAR(255),                                                     -- 칵테일 재료 양 8
	COCKTAIL_MEASURE9     VARCHAR(255),                                                     -- 칵테일 재료 양 9
	COCKTAIL_MEASURE10    VARCHAR(255),                                                     -- 칵테일 재료 양 10
	COCKTAIL_MEASURE11    VARCHAR(255),                                                     -- 칵테일 재료 양 11
	COCKTAIL_MEASURE12    VARCHAR(255),                                                     -- 칵테일 재료 양 12
	COCKTAIL_MEASURE13    VARCHAR(255),                                                     -- 칵테일 재료 양 13
	COCKTAIL_MEASURE14    VARCHAR(255),                                                     -- 칵테일 재료 양 14
	COCKTAIL_MEASURE15    VARCHAR(255),                                                     -- 칵테일 재료 양 15
	RC_TASTE              VARCHAR(255),                                                     -- 기호 조사
	CONSTRAINT FK_WEATHER_COCKTAIL FOREIGN KEY (RC_WEATHER) REFERENCES WEATHER (WEATHER_ID) -- 외래 키 제약조건
);

-- 안주 테이블 생성
CREATE TABLE SNACK
(
	SNACK_ID    BIGINT AUTO_INCREMENT PRIMARY KEY,     -- 안주 ID
	NAME        VARCHAR(255) NOT NULL,              -- 안주 이름
	SNACK_IMG   VARCHAR(255),                       -- 안주 이미지
	DESCRIPTION TEXT         NOT NULL,              -- 설명
	CREATED_AT  TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- 생성 시간
);

-- 멤버 테이블 생성
CREATE TABLE MEMBER
(
	MEMBER_ID       BIGINT        NOT NULL PRIMARY KEY,                                   -- 회원 ID
	MEMBER_NM       NVARCHAR(255) NOT NULL,                                               -- 회원 이름
	EMAIL           NVARCHAR(255) NOT NULL,                                               -- 로그인 정보
	MEMBER_PW       NVARCHAR(50)  NULL,                                                   -- 소셜 로그인인 경우 NULL 허용
	MEMBER_YMD      NVARCHAR(8)   NULL,                                                   -- 생년월일
	GENDER          CHAR(1)       NULL,                                                   -- 성별 (M: 남, F: 여)
	MEMBER_PH       NVARCHAR(11)  NULL,                                                   -- 핸드폰 번호 (- 제외)
	MEMBER_ROLE     NVARCHAR(5)   NOT NULL,                                               -- 회원 권한 (가입 로직 완료시 부여)
	LOGIN_TYPE      CHAR(1)       NOT NULL,                                               -- 소셜/기본 회원가입 여부 (소셜로그인의 경우 Y, 아닐 경우 N)
	TOKEN_ID        NVARCHAR(100),                                                        -- 토큰 코드
	MER_TASTE       NVARCHAR(50)  NULL,                                                   -- 간단한 기호조사
	RECORD_RES      NVARCHAR(255) NULL,                                                   -- 결과 (외래 키)
	WITHDRAWAL_DATE DATETIME      NOT NULL,                                               -- 탈퇴일자 (데이터 자동삭제 스케줄러 설정)
	CONSTRAINT FK_RECORD_MEMBER FOREIGN KEY (RECORD_RES) REFERENCES RECORD (QUESTION_CD), -- 외래 키 제약조건
	INDEX IDX_MEMBER_ROLE (MEMBER_ROLE)                                                   -- 인덱스 추가
);

-- 토큰 테이블 생성
CREATE TABLE JWT_TOKEN
(
	TOKEN_ID   NVARCHAR(100) NOT NULL PRIMARY KEY,                                   -- 토큰 ID
	MEMBER_ID  BIGINT NOT NULL,                                               -- 멤버 ID
	TOKEN      TEXT          NOT NULL,                                               -- 토큰
	CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                                  -- 생성 시간
	CONSTRAINT FK_MEMBER_TOKEN FOREIGN KEY (MEMBER_ID) REFERENCES MEMBER (MEMBER_ID) -- 외래 키 제약조건
);

-- 커스텀 칵테일 테이블 생성
CREATE TABLE CUSTOM_COCKTAIL
(
	CUSTOM_ID           BIGINT        NOT NULL AUTO_INCREMENT PRIMARY KEY, -- 칵테일 ID
	CUSTOM_NM           NVARCHAR(255) NOT NULL,                            -- 칵테일 이름
	CUSTOM_RCP          NVARCHAR(255) NOT NULL,                            -- 레시피 내용
	MEMBER_ID           BIGINT        NOT NULL,                            -- 멤버 ID
	CUSTOM_IMAGE_URL    VARCHAR(255),                                      -- 커스텀 칵테일 이미지 URL
	CUSTOM_INGREDIENT1  VARCHAR(255),                                      -- 칵테일 재료 1번
	CUSTOM_INGREDIENT2  VARCHAR(255),                                      -- 칵테일 재료 2번
	CUSTOM_INGREDIENT3  VARCHAR(255),                                      -- 칵테일 재료 3번
	CUSTOM_INGREDIENT4  VARCHAR(255),                                      -- 칵테일 재료 4번
	CUSTOM_INGREDIENT5  VARCHAR(255),                                      -- 칵테일 재료 5번
	CUSTOM_INGREDIENT6  VARCHAR(255),                                      -- 칵테일 재료 6번
	CUSTOM_INGREDIENT7  VARCHAR(255),                                      -- 칵테일 재료 7번
	CUSTOM_INGREDIENT8  VARCHAR(255),                                      -- 칵테일 재료 8번
	CUSTOM_INGREDIENT9  VARCHAR(255),                                      -- 칵테일 재료 9번
	CUSTOM_INGREDIENT10 VARCHAR(255),                                      -- 칵테일 재료 10번
	CUSTOM_INGREDIENT11 VARCHAR(255),                                      -- 칵테일 재료 11번
	CUSTOM_INGREDIENT12 VARCHAR(255),                                      -- 칵테일 재료 12번
	CUSTOM_INGREDIENT13 VARCHAR(255),                                      -- 칵테일 재료 13번
	CUSTOM_INGREDIENT14 VARCHAR(255),                                      -- 칵테일 재료 14번
	CUSTOM_INGREDIENT15 VARCHAR(255),                                      -- 칵테일 재료 15번
	CUSTOM_MEASURE1     VARCHAR(255),                                      -- 1번 칵테일 재료 양
	CUSTOM_MEASURE2     VARCHAR(255),                                      -- 2번 칵테일 재료 양
	CUSTOM_MEASURE3     VARCHAR(255),                                      -- 3번 칵테일 재료 양
	CUSTOM_MEASURE4     VARCHAR(255),                                      -- 4번 칵테일 재료 양
	CUSTOM_MEASURE5     VARCHAR(255),                                      -- 5번 칵테일 재료 양
	CUSTOM_MEASURE6     VARCHAR(255),                                      -- 6번 칵테일 재료 양
	CUSTOM_MEASURE7     VARCHAR(255),                                      -- 7번 칵테일 재료 양
	CUSTOM_MEASURE8     VARCHAR(255),                                      -- 8번 칵테일 재료 양
	CUSTOM_MEASURE9     VARCHAR(255),                                      -- 9번 칵테일 재료 양
	CUSTOM_MEASURE10    VARCHAR(255),                                      -- 10번 칵테일 재료 양
	CUSTOM_MEASURE11    VARCHAR(255),                                      -- 11번 칵테일 재료 양
	CUSTOM_MEASURE12    VARCHAR(255),                                      -- 12번 칵테일 재료 양
	CUSTOM_MEASURE13    VARCHAR(255),                                      -- 13번 칵테일 재료 양
	CUSTOM_MEASURE14    VARCHAR(255),                                      -- 14번 칵테일 재료 양
	CUSTOM_MEASURE15    VARCHAR(255),                                      -- 15번 칵테일 재료 양
	CONSTRAINT FK_CUSTOM_COCKTAIL_MEMBER FOREIGN KEY (MEMBER_ID) REFERENCES MEMBER (MEMBER_ID)
);

-- 게시판 테이블 생성
CREATE TABLE BOARD
(
	BOARD_ID           BIGINT AUTO_INCREMENT PRIMARY KEY,                                                          -- 게시글 ID
	MEMBER_ID          BIGINT NOT NULL,                                                                  -- 멤버 ID
	CUSTOM_ID          BIGINT NOT NULL,                                                                           -- 커스텀 칵테일 ID
	TITLE              VARCHAR(255)  NOT NULL,                                                                  -- 글 제목
	CONTENT            TEXT          NOT NULL,                                                                  -- 글 내용
	CREATED_AT         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                                                     -- 생성 시간
	UPDATED_AT         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,                         -- 수정 시간
	CONSTRAINT FK_MEMBER_BOARD FOREIGN KEY (MEMBER_ID) REFERENCES MEMBER (MEMBER_ID),                           -- 외래 키 제약조건
	CONSTRAINT FK_CUSTOM_COCKTAIL_BOARD FOREIGN KEY (CUSTOM_ID) REFERENCES CUSTOM_COCKTAIL (CUSTOM_ID) -- 외래 키 제약조건
);

-- 조회수 테이블 생성
CREATE TABLE VIEW_LOG
(
	VIEW_ID   BIGINT AUTO_INCREMENT PRIMARY KEY,                                       -- 조회 ID
	BOARD_ID  BIGINT NOT NULL,                                               -- 게시글 ID
	MEMBER_ID BIGINT NOT NULL,                                               -- 멤버 ID
	VIEW_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                                  -- 조회 시간
	CONSTRAINT FK_BOARD_VIEW FOREIGN KEY (BOARD_ID) REFERENCES BOARD (BOARD_ID),    -- 외래 키 제약조건
	CONSTRAINT FK_MEMBER_VIEW FOREIGN KEY (MEMBER_ID) REFERENCES MEMBER (MEMBER_ID) -- 외래 키 제약조건
);

-- 투표_선택 테이블 생성
CREATE TABLE CHOICEVOTER
(
	CHOICEVOTER_ID BIGINT AUTO_INCREMENT PRIMARY KEY,                                          -- 기본식별자, 자동 증가
	CHOICE_ID      BIGINT NOT NULL,                                                  -- 선택ID
	MEMBER_ID      BIGINT NOT NULL,                                                  -- 멤버ID
	CONSTRAINT FK_CHOICEVOTER_CHOICE FOREIGN KEY (CHOICE_ID) REFERENCES CHOICE (CHOICE_ID), -- 외래 키 제약조건
	CONSTRAINT FK_CHOICEVOTER_MEMBER FOREIGN KEY (MEMBER_ID) REFERENCES MEMBER (MEMBER_ID)  -- 외래 키 제약조건
);
